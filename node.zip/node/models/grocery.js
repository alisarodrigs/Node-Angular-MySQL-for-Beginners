const db = require("../util/database");

module.exports = class Grocery {
  constructor(id, item) {
    this.id = id;
    this.item = item;
  }

  static fetchAll() {
    return db.execute("SELECT * FROM GROCERIES");
  }

  static post(item) {
    return db.execute("INSERT INTO GROCERIES (item) VALUE (?)", [item]);
  }

  static update(id, item) {
    return db.execute("UPDATE GROCERIES SET ITEM = ? WHERE ID = ?", [item, id]);
  }

  static delete(id) {
    return db.execute("DELETE FROM GROCERIES WHERE ID = ?", [id]);
  }



};
