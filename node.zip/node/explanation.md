1. mvc - model, controller
2. index.js -> model -> routes -> controller -> config -> util -> controllers/error
3. MODEL has Grocery class and there is a ROUTE (can specify child route) where we call the CONTROLLER method; index.js uses the ROUTE file to call using '/groceries'
4. config(security layer for user & pwd) and util files are for connection to mysql, where we get data in MODEL class. in CONTROLLER, we call db using async (try-catch)
5. error in controller folder is called in index.js
6. headers in index.js. 
7. Body-Parser in index.js is to convert to json structure.
8. if we change alisa mysql connection, we will see change in browser