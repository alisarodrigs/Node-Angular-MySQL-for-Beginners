export interface Grocery{
  id: number;
  item: string;
}
